package JSON_Utils;

import java.io.Serializable;

public class JSON_Writer {
    String action;
    String[] data;



}