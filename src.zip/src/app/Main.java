package app;

import view.GameView;

public class Main {
    public static void main(String[] args) {
        // Launch JavaFX application
        GameView.launch(GameView.class, args);
    }
}